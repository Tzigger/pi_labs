file(REMOVE_RECURSE
  "CMakeFiles/lab13.dir/color_spaces.cpp.o"
  "CMakeFiles/lab13.dir/color_spaces.cpp.o.d"
  "CMakeFiles/lab13.dir/main_lab13.cpp.o"
  "CMakeFiles/lab13.dir/main_lab13.cpp.o.d"
  "lab13"
  "lab13.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/lab13.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
